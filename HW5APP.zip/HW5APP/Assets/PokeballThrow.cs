using System.Collections;
using UnityEngine;

public class PokeballThrow : MonoBehaviour
{
    public Transform pokemon;
    public GameObject captureEffect;
    public float duration = 1.5f;
    public float arcHeight = 3f;

    [Header("抖動設定")]
    public float shakeTime = 1.2f;    // 抖動總時間（秒）
    public float shakeSpeed = 25f;    // 抖動頻率
    public float shakeAngle = 25f;    // 左右擺動角度
    public float groundOffset = 0.15f;  // 球心離地面的高度，約等於球的半徑

    Vector3 start;
    float t;
    bool thrown;
    bool hit;

    void Start() { start = transform.position; }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) thrown = true;
        if (!thrown || hit) return;

        t += Time.deltaTime / duration;
        Vector3 target = pokemon.position + Vector3.up * 0.5f;
        Vector3 pos = Vector3.Lerp(start, target, t);
        pos.y += Mathf.Sin(Mathf.Clamp01(t) * Mathf.PI) * arcHeight;
        transform.position = pos;
        transform.Rotate(0, 0, 720 * Time.deltaTime);

        if (t >= 1f)
        {
            hit = true;
            StartCoroutine(Capture());
        }
    }

    IEnumerator Capture()
    {
        // 1. 寶可夢一邊縮小一邊飛進球裡
        Vector3 originalScale = pokemon.localScale;
        Vector3 originalPos = pokemon.position;
        float s = 0f;
        while (s < 1f)
        {
            s += Time.deltaTime / 0.5f;
            pokemon.localScale = Vector3.Lerp(originalScale, Vector3.zero, s);
            pokemon.position = Vector3.Lerp(originalPos, transform.position, s);
            yield return null;
        }
        pokemon.gameObject.SetActive(false);
        pokemon.localScale = originalScale;
        pokemon.position = originalPos;
        
        // 1.5 球落到地面並彈一下
        float groundY = transform.position.y;
        RaycastHit hitInfo;
        if (Physics.Raycast(transform.position, Vector3.down, out hitInfo, 50f))
            groundY = hitInfo.point.y + groundOffset;

        float v = 0f;
        while (transform.position.y > groundY)
        {
            v += 15f * Time.deltaTime;                 // 重力加速
            Vector3 p = transform.position;
            p.y = Mathf.Max(groundY, p.y - v * Time.deltaTime);
            transform.position = p;
            yield return null;
        }

        float b = 0f;
        while (b < 1f)
        {
            b += Time.deltaTime / 0.25f;               // 小彈跳 0.25 秒
            Vector3 p = transform.position;
            p.y = groundY + Mathf.Sin(b * Mathf.PI) * 0.3f;
            transform.position = p;
            yield return null;
        }
        Vector3 end = transform.position;
        end.y = groundY;
        transform.position = end;

        // 2. 球左右抖動，幅度逐漸變小
        Quaternion baseRot = transform.rotation;
        float timer = 0f;
        while (timer < shakeTime)
        {
            timer += Time.deltaTime;
            float damping = 1f - timer / shakeTime;
            float angle = Mathf.Sin(timer * shakeSpeed) * shakeAngle * damping;
            transform.rotation = baseRot * Quaternion.Euler(0, 0, angle);
            yield return null;
        }
        transform.rotation = baseRot;

        // 3. 靜止一下，再冒出收服特效
        yield return new WaitForSeconds(0.3f);
        if (captureEffect != null)
            Instantiate(captureEffect, transform.position, Quaternion.identity);
    }
}